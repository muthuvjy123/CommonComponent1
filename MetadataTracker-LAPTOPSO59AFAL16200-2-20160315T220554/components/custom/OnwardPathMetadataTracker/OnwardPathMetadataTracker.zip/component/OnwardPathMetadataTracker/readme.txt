﻿OnwardPathMetadataTracker Component : Version 1.0 (03/15/2016)
-----------------------------------
In the current Oracle Webcenter Content environment there is no option available to find out which metadata value got updated by whom and When and what is the latest and old value.

By installing and enabling this "OnwardPathMetadataTracker" custom component users can come to know who has updated the document and old value and new updated value and time from a 
"Metadata Tracker" link on content information page.

In the "MetadataTrackerList" environment field the metadata's which need to be tracked can be listed as comma seperated. Only the metadata's mentioned in this varialbe will be tracked and 
other metadata updates will not be tracked.
